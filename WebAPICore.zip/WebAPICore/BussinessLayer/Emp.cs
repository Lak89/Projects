﻿using BussinessContract;
using System;
using System.Collections.Generic;
using System.Text;

namespace BussinessLayer
{
    public class Emp:IEmp
    {
        public string GetName()
        {
            return "Lakshman";
        }
    }
}
