﻿using BussinessContract;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using WebAPICore.Controllers;
using Xunit;

namespace WebAPITest
{
    public class EmpControllerTest
    {
        private readonly Mock<IEmp> mockRepo;
        private readonly EmpController controller;
        public EmpControllerTest()
        {
            mockRepo = new Mock<IEmp>();
            controller = new EmpController(mockRepo.Object);
        }

        [Fact]
        public void GetName_valid()
        {
            var name = "Lak";
            // Arrange
            mockRepo.Setup(repo => repo.GetName()).Returns(name);

            // Act
            var result = controller.GetName();

            // Assert
            Assert.IsType<OkObjectResult>(result);
            var viewResult = Assert.IsType<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<OkObjectResult>(viewResult);
            Assert.Equal(model, viewResult);

        }
    }
}
