﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace WebAPITest
{
    public class ValueControllerTest
    {


        public  ValueControllerTest()
        {

        }

        [Fact]
        public void Test1()
        {

        }
    }
}
