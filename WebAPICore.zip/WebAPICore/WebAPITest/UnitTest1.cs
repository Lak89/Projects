using System;
using Xunit;

namespace WebAPITest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
