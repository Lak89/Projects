﻿using BussinessContract;
using Microsoft.AspNetCore.Mvc;

namespace WebAPICore.Controllers
{

    [Route("api/[controller]/[action]")]
    public class EmpController : Controller
    {
        private IEmp _emp;
        public EmpController(IEmp emp)
        {
            _emp = emp;
        }

        [HttpGet]
        public IActionResult GetName()
        {
           var name= _emp.GetName();
           return Ok(name);
        }
    }
}