﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BussinessContract
{
    public interface IEmp
    {
        string GetName();
    }
}
